
import os

from flask import Flask

from dotenv import load_dotenv

from database.db import create_tables
from database.free_insurance_db import create_free_tables
from database.workshop_insurance_db import create_workshop_tables

from routes.auth import auth
from routes.dashboard import dashboard


# ==========================================
# خواندن فایل .env
# ==========================================

load_dotenv()


# ==========================================
# ساخت برنامه Flask
# ==========================================

app = Flask(__name__)


# ==========================================
# Secret Key
# ==========================================

app.secret_key = os.getenv(
    "SECRET_KEY"
)


# ==========================================
# ساخت دیتابیس اصلی
# ==========================================

create_tables()


# ==========================================
# ساخت دیتابیس بیمه آزاد
# ==========================================

create_free_tables()


# ==========================================
# ساخت دیتابیس بیمه کارگاهی
# ==========================================

create_workshop_tables()


# ==========================================
# ثبت Blueprint ها
# ==========================================

app.register_blueprint(auth)

app.register_blueprint(dashboard)


# ==========================================
# اجرای برنامه
# ==========================================

if __name__ == "__main__":

    app.run(
        debug=True
    )