
const addRowBtn =
    document.getElementById("addRowBtn");

const personsBody =
    document.getElementById("personsBody");


// ======================================
// افزودن سطر
// ======================================

addRowBtn.addEventListener(
    "click",
    function () {

        const row =
            document.createElement("tr");

        row.className =
            "person-row";


        row.innerHTML = `

    <td class="row-number">
        1
    </td>


    <td>

        <input
            type="text"
            name="workshop_name"
            class="person-input"
            placeholder="نام کارگاه"
        >

    </td>


    <td>

        <input
            type="text"
            name="workshop_code"
            class="person-input"
            placeholder="کد کارگاه"
        >

    </td>


    <td>

        <input
            type="text"
            name="first_name"
            class="person-input first-name"
            placeholder="نام"
        >

    </td>


    <td>

        <input
            type="text"
            name="last_name"
            class="person-input last-name"
            placeholder="نام خانوادگی"
        >

    </td>


    <td>

        <input
            type="text"
            name="mobile"
            class="person-input"
            placeholder="09xxxxxxxxx"
        >

    </td>


    <td>

        <input
            type="text"
            name="national_code"
            class="person-input"
            placeholder="کد ملی"
        >

    </td>


    <td>

        <input
            type="text"
            name="password"
            class="person-input"
            placeholder="رمز عبور"
        >

    </td>


    <td>

        <input
            type="text"
            name="registration_date"
            class="person-input registration-date"
            placeholder="1405/06/31"
            maxlength="10"
            inputmode="numeric"
        >

    </td>


    <td>

        <button
            type="button"
            class="delete-btn"
        >
            🗑
        </button>

    </td>

`;

        personsBody.appendChild(row);


        updateNumbers();


        row.querySelector(
            'input[name="full_name"]'
        ).focus();

    }
);


// ======================================
// حذف
// ======================================

personsBody.addEventListener(
    "click",
    function (event) {

        const button =
            event.target.closest(
                ".delete-btn"
            );


        if (!button) {
            return;
        }


        const personId =
            button.dataset.id;


        // اگر شخص قبلاً در دیتابیس است
        if (personId) {

            deletePerson(personId);

            return;
        }


        // اگر هنوز ذخیره نشده
        const row =
            button.closest(
                ".person-row"
            );


        const rows =
            personsBody.querySelectorAll(
                ".person-row"
            );


        if (rows.length === 1) {

            row.querySelectorAll(
                "input"
            ).forEach(
                input => input.value = ""
            );

            return;
        }


        row.remove();


        updateNumbers();

    }
);


// ======================================
// شماره ردیف
// ======================================

function updateNumbers() {

    const rows =
        personsBody.querySelectorAll(
            ".person-row"
        );


    rows.forEach(
        function (row, index) {

            row.querySelector(
                ".row-number"
            ).textContent =
                index + 1;

        }
    );
}


// ======================================
// حذف از دیتابیس
// ======================================

function deletePerson(personId) {

    const answer =
        confirm(
            "آیا از حذف این شخص مطمئن هستید؟"
        );


    if (!answer) {
        return;
    }


    const form =
        document.createElement("form");


    form.method = "POST";


    form.action =
        "/workshop-insurance/person/"
        + personId
        + "/delete";


    document.body.appendChild(form);


    form.submit();
}

// ==========================================
// ساخت full_name از نام + نام خانوادگی
// ==========================================

document
    .getElementById("personsForm")
    .addEventListener(
        "submit",
        function () {

            const rows =
                document.querySelectorAll(
                    ".person-row"
                );


            rows.forEach(function (row) {

                const firstName =
                    row.querySelector(
                        ".first-name"
                    );


                const lastName =
                    row.querySelector(
                        ".last-name"
                    );


                if (!firstName || !lastName) {
                    return;
                }


                const fullName =
                    (
                        firstName.value.trim()
                        + " "
                        + lastName.value.trim()
                    ).trim();


                let hiddenInput =
                    row.querySelector(
                        ".full-name-hidden"
                    );


                if (!hiddenInput) {

                    hiddenInput =
                        document.createElement(
                            "input"
                        );

                    hiddenInput.type = "hidden";

                    hiddenInput.name =
                        "full_name";

                    hiddenInput.className =
                        "full-name-hidden";

                    row.appendChild(
                        hiddenInput
                    );
                }


                hiddenInput.value =
                    fullName;

            });

        }
    );


// ==========================================
// تاریخ با / خودکار
// مثال:
// 14050631
// تبدیل می‌شود به:
// 1405/06/31
// ==========================================

document.addEventListener(
    "input",
    function (event) {

        if (
            !event.target.classList.contains(
                "registration-date"
            )
        ) {
            return;
        }


        let value =
            event.target.value
                .replace(/\D/g, "")
                .slice(0, 8);


        if (value.length > 4) {

            value =
                value.slice(0, 4)
                + "/"
                + value.slice(4);

        }


        if (value.length > 7) {

            value =
                value.slice(0, 7)
                + "/"
                + value.slice(7);

        }


        event.target.value = value;

    }
);