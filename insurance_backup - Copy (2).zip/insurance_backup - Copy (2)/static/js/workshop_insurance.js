// // ==========================================
// // گرفتن تمام ردیف های اشخاص
// // ==========================================

// const personRows =
//     document.querySelectorAll(".person-row");


// // ==========================================
// // گرفتن جستجو
// // ==========================================

// const searchInput =
//     document.getElementById("searchInput");


// // ==========================================
// // جستجوی نام
// // ==========================================

// searchInput.addEventListener(
//     "input",
//     function () {

//         const searchText =
//             this.value.trim().toLowerCase();

//         personRows.forEach(function (row) {

//             const name =
//                 row.dataset.name.toLowerCase();

//             if (
//                 name.includes(searchText)
//             ) {
//                 row.style.display = "";
//             }
//             else {
//                 row.style.display = "none";
//             }
//         });
//     }
// );


// // ==========================================
// // تمام checkbox های پرداخت
// // ==========================================

// const paymentCheckboxes =
//     document.querySelectorAll(
//         ".payment-checkbox"
//     );


// // ==========================================
// // تغییر وضعیت پرداخت
// // ==========================================

// paymentCheckboxes.forEach(
//     function (checkbox) {

//         checkbox.addEventListener(
//             "change",
//             function () {

//                 const personId =
//                     this.dataset.personId;

//                 const paid =
//                     this.checked ? 1 : 0;

//                 const row =
//                     this.closest(".person-row");

//                 const status =
//                     this.closest(".payment-status");

//                 const statusText =
//                     status.querySelector(
//                         ".status-text"
//                     );

//                 const customCheck =
//                     status.querySelector(
//                         ".custom-check"
//                     );


//                 // ==================================
//                 // تغییر ظاهر
//                 // ==================================

//                 if (this.checked) {

//                     status.classList.remove(
//                         "unpaid"
//                     );

//                     status.classList.add(
//                         "paid"
//                     );

//                     statusText.textContent =
//                         "پرداخت شده";

//                     customCheck.textContent =
//                         "✓";
//                 }

//                 else {

//                     status.classList.remove(
//                         "paid"
//                     );

//                     status.classList.add(
//                         "unpaid"
//                     );

//                     statusText.textContent =
//                         "پرداخت نشده";

//                     customCheck.textContent =
//                         "×";
//                 }


//                 // ==================================
//                 // ذخیره در دیتابیس
//                 // ==================================

//                 savePayment(
//                     personId,
//                     paid
//                 );
//             }
//         );
//     }
// );


// // ==========================================
// // ذخیره پرداخت
// // ==========================================

// function savePayment(
//     personId,
//     paid
// ) {

//     const year =
//         document.getElementById(
//             "year"
//         ).value;

//     const month =
//         document.getElementById(
//             "month"
//         ).value;


//     const descriptionInput =
//         document.querySelector(
//             `.description-input[data-person-id="${personId}"]`
//         );


//     const description =
//         descriptionInput
//             ? descriptionInput.value
//             : "";


//     const formData =
//         new FormData();


//     formData.append(
//         "person_id",
//         personId
//     );

//     formData.append(
//         "year",
//         year
//     );

//     formData.append(
//         "month",
//         month
//     );

//     formData.append(
//         "paid",
//         paid
//     );

//     formData.append(
//         "description",
//         description
//     );


//     // ==========================================
//     // ارسال به Flask
//     // ==========================================

//     fetch(
//         "/workshop-insurance/payment/toggle",
//         {
//             method: "POST",
//             body: formData
//         }
//     )

//     .then(function (response) {

//         return response.json();

//     })

//     .then(function (data) {

//         if (!data.success) {

//             alert(
//                 "ذخیره وضعیت پرداخت انجام نشد."
//             );
//         }

//     })

//     .catch(function () {

//         alert(
//             "ارتباط با سرور برقرار نشد."
//         );
//     });
// }


// // ==========================================
// // ذخیره توضیحات
// // ==========================================

// function saveDescriptions() {

//     const checkboxes =
//         document.querySelectorAll(
//             ".payment-checkbox"
//         );


//     checkboxes.forEach(
//         function (checkbox) {

//             const personId =
//                 checkbox.dataset.personId;

//             const paid =
//                 checkbox.checked ? 1 : 0;


//             savePayment(
//                 personId,
//                 paid
//             );
//         }
//     );


//     alert(
//         "اطلاعات ذخیره شد."
//     );
// }








// ==========================================
// گرفتن تمام ردیف های اشخاص
// ==========================================
const personRows = document.querySelectorAll(".person-row");

// ==========================================
// گرفتن جستجو
// ==========================================
const searchInput = document.getElementById("searchInput");

if (searchInput) {
    searchInput.addEventListener("input", function () {
        const searchText = this.value.trim().toLowerCase();

        personRows.forEach(function (row) {
            const name = (row.dataset.name || "").toLowerCase();
            if (name.includes(searchText)) {
                row.style.display = "";
            } else {
                row.style.display = "none";
            }
        });
    });
}

// ==========================================
// ماسک خودکار تاریخ با درج اسلش (1405/01/15)
// ==========================================
function setupDateMask(input) {
    input.addEventListener("input", function () {
        // تبدیل ارقام فارسی و عربی به انگلیسی
        let val = this.value
            .replace(/[۰-۹]/g, d => "۰۱۲۳۴۵۶۷۸۹".indexOf(d))
            .replace(/[٠-٩]/g, d => "٠١٢٣٤٥٦٧٨٩".indexOf(d));

        // فقط نگه‌داشتن اعداد
        let clean = val.replace(/\D/g, "");

        if (clean.length > 8) {
            clean = clean.substring(0, 8);
        }

        // ساخت فرمت سال/ماه/روز
        let formatted = "";
        if (clean.length > 0) {
            formatted = clean.substring(0, 4);
            if (clean.length > 4) {
                formatted += "/" + clean.substring(4, 6);
                if (clean.length > 6) {
                    formatted += "/" + clean.substring(6, 8);
                }
            }
        }

        this.value = formatted;
    });

    // حذف اسلش قبلی هنگام زدن Backspace
    input.addEventListener("keydown", function (e) {
        if (e.key === "Backspace" && this.value.endsWith("/")) {
            this.value = this.value.slice(0, -1);
        }
    });

    // با زدن Enter در فیلد تاریخ، ذخیره انجام شود
    input.addEventListener("keydown", function (e) {
        if (e.key === "Enter") {
            e.preventDefault();
            const personId = this.dataset.personId;
            const checkbox = document.querySelector(`.payment-checkbox[data-person-id="${personId}"]`);
            const paid = checkbox && checkbox.checked ? 1 : 0;
            savePayment(personId, paid, true);
        }
    });
}

// اعمال ماسک روی همه اینپوت‌های تاریخ
document.querySelectorAll(".record-date-input").forEach(input => {
    setupDateMask(input);
});

// اینتر زدن در توضیحات هم ذخیره کند
document.querySelectorAll(".description-input").forEach(input => {
    input.addEventListener("keydown", function (e) {
        if (e.key === "Enter") {
            e.preventDefault();
            const personId = this.dataset.personId;
            const checkbox = document.querySelector(`.payment-checkbox[data-person-id="${personId}"]`);
            const paid = checkbox && checkbox.checked ? 1 : 0;
            savePayment(personId, paid, true);
        }
    });
});

// ==========================================
// تمام checkbox های پرداخت
// ==========================================
const paymentCheckboxes = document.querySelectorAll(".payment-checkbox");

paymentCheckboxes.forEach(function (checkbox) {
    checkbox.addEventListener("change", function () {
        const personId = this.dataset.personId;
        const paid = this.checked ? 1 : 0;
        const status = this.closest(".payment-status");
        const statusText = status.querySelector(".status-text");
        const customCheck = status.querySelector(".custom-check");

        // تغییر ظاهر
        if (this.checked) {
            status.classList.remove("unpaid");
            status.classList.add("paid");
            statusText.textContent = "پرداخت شده";
            customCheck.textContent = "✓";
        } else {
            status.classList.remove("paid");
            status.classList.add("unpaid");
            statusText.textContent = "پرداخت نشده";
            customCheck.textContent = "×";
        }

        // ذخیره در دیتابیس
        savePayment(personId, paid, false);
    });
});

// ==========================================
// ذخیره پرداخت، تاریخ ثبت و توضیحات
// ==========================================
function savePayment(personId, paid, showAlert = false) {
    const year = document.getElementById("year").value;
    const month = document.getElementById("month").value;

    const descriptionInput = document.querySelector(`.description-input[data-person-id="${personId}"]`);
    const description = descriptionInput ? descriptionInput.value.trim() : "";

    const recordDateInput = document.querySelector(`.record-date-input[data-person-id="${personId}"]`);
    const recordDate = recordDateInput ? recordDateInput.value.trim() : "";

    const formData = new FormData();
    formData.append("person_id", personId);
    formData.append("year", year);
    formData.append("month", month);
    formData.append("paid", paid);
    formData.append("description", description);
    formData.append("record_date", recordDate);

    fetch("/workshop-insurance/payment/toggle", {
        method: "POST",
        body: formData
    })
    .then(response => response.json())
    .then(data => {
        if (!data.success) {
            alert("ذخیره اطلاعات انجام نشد.");
        } else if (showAlert) {
            alert("اطلاعات ذخیره شد.");
        }
    })
    .catch(() => {
        alert("ارتباط با سرور برقرار نشد.");
    });
}

// ==========================================
// دکمه بالای صفحه: ذخیره همه
// ==========================================
function saveDescriptions() {
    const checkboxes = document.querySelectorAll(".payment-checkbox");
    let completed = 0;
    const total = checkboxes.length;

    if (total === 0) return;

    checkboxes.forEach(function (checkbox) {
        const personId = checkbox.dataset.personId;
        const paid = checkbox.checked ? 1 : 0;
        const year = document.getElementById("year").value;
        const month = document.getElementById("month").value;

        const descriptionInput = document.querySelector(`.description-input[data-person-id="${personId}"]`);
        const description = descriptionInput ? descriptionInput.value.trim() : "";

        const recordDateInput = document.querySelector(`.record-date-input[data-person-id="${personId}"]`);
        const recordDate = recordDateInput ? recordDateInput.value.trim() : "";

        const formData = new FormData();
        formData.append("person_id", personId);
        formData.append("year", year);
        formData.append("month", month);
        formData.append("paid", paid);
        formData.append("description", description);
        formData.append("record_date", recordDate);

        fetch("/workshop-insurance/payment/toggle", {
            method: "POST",
            body: formData
        }).finally(() => {
            completed++;
            if (completed === total) {
                alert("تمامی اطلاعات با موفقیت ذخیره شدند.");
            }
        });
    });
}
