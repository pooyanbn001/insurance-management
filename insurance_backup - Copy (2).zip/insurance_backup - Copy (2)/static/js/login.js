// پیدا کردن فرم
const loginForm = document.getElementById("loginForm");


// // زمانی که فرم ارسال شود
loginForm.addEventListener("submit", function(event) {

//     // جلوگیری از رفتار پیش فرض فرم
//     // event.preventDefault();

    console.log("فرم ارسال شد");

});

const password = document.getElementById("password");
const togglePassword = document.getElementById("togglePassword");

togglePassword.addEventListener("click", function () {

    if (password.type === "password") {
        password.type = "text";
    } else {
        password.type = "password";
    }

});

