
const addRowBtn =
    document.getElementById("addRowBtn");

const personsBody =
    document.getElementById("personsBody");


// ======================================
// افزودن سطر
// ======================================

addRowBtn.addEventListener(
    "click",
    function () {

        const row =
            document.createElement("tr");

        row.className =
            "person-row";


        row.innerHTML = `

            <td class="row-number">
                1
            </td>

<td>
    <input
        type="text"
        name="first_name"
        class="person-input"
        placeholder="نام"
    >
</td>

<td>
    <input
        type="text"
        name="last_name"
        class="person-input"
        placeholder="نام خانوادگی"
    >
</td>

            <td>
                <input
                    type="text"
                    name="mobile"
                    class="person-input"
                    placeholder="09xxxxxxxxx"
                >
            </td>

            <td>
                <input
                    type="text"
                    name="national_code"
                    class="person-input"
                    placeholder="کد ملی"
                >
            </td>

            <td>
                <input
                    type="text"
                    name="password"
                    class="person-input"
                    placeholder="رمز عبور"
                >
            </td>

            <td>

                <button
                    type="button"
                    class="delete-btn"
                >
                    🗑
                </button>

            </td>
        `;


        personsBody.appendChild(row);


        updateNumbers();


row.querySelector(
    'input[name="first_name"]'
).focus();
    }
);


// ======================================
// حذف
// ======================================

personsBody.addEventListener(
    "click",
    function (event) {

        const button =
            event.target.closest(
                ".delete-btn"
            );


        if (!button) {
            return;
        }


        const personId =
            button.dataset.id;


        // اگر شخص قبلاً در دیتابیس است

        if (personId) {

            deletePerson(personId);

            return;

        }


        // اگر هنوز ذخیره نشده

        const row =
            button.closest(
                ".person-row"
            );


        const rows =
            personsBody.querySelectorAll(
                ".person-row"
            );


        if (rows.length === 1) {

            row.querySelectorAll(
                "input"
            ).forEach(
                input => input.value = ""
            );

            return;
        }


        row.remove();


        updateNumbers();

    }
);


// ======================================
// شماره ردیف
// ======================================

function updateNumbers() {

    const rows =
        personsBody.querySelectorAll(
            ".person-row"
        );


    rows.forEach(
        function (row, index) {

            row.querySelector(
                ".row-number"
            ).textContent =
                index + 1;

        }
    );

}


// ======================================
// حذف از دیتابیس
// ======================================

function deletePerson(personId) {

    const answer =
        confirm(
            "آیا از حذف این شخص مطمئن هستید؟"
        );


    if (!answer) {
        return;
    }


    const form =
        document.createElement("form");


    form.method = "POST";


    form.action =
        "/free-insurance/person/"
        + personId
        + "/delete";


    document.body.appendChild(form);


    form.submit();
}