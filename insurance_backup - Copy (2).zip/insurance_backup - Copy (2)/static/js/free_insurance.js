

// const personRows =
//     document.querySelectorAll(".person-row");


// // ==========================================
// // گرفتن جستجو
// // ==========================================

// const searchInput =
//     document.getElementById("searchInput");


// // ==========================================
// // جستجوی نام
// // ==========================================

// searchInput.addEventListener(
//     "input",
//     function () {


//         const searchText =
//             this.value.trim().toLowerCase();


//         personRows.forEach(function (row) {


//             const name =
//                 row.dataset.name.toLowerCase();


//             if (
//                 name.includes(searchText)
//             ) {

//                 row.style.display = "";

//             }

//             else {

//                 row.style.display = "none";

//             }

//         });

//     }
// );



// // ==========================================
// // تمام checkbox های پرداخت
// // ==========================================

// const paymentCheckboxes =
//     document.querySelectorAll(
//         ".payment-checkbox"
//     );


// // ==========================================
// // تغییر وضعیت پرداخت
// // ==========================================

// paymentCheckboxes.forEach(
//     function (checkbox) {


//         checkbox.addEventListener(
//             "change",
//             function () {


//                 const personId =
//                     this.dataset.personId;


//                 const paid =
//                     this.checked ? 1 : 0;


//                 const row =
//                     this.closest(".person-row");


//                 const status =
//                     this.closest(".payment-status");


//                 const statusText =
//                     status.querySelector(
//                         ".status-text"
//                     );


//                 const customCheck =
//                     status.querySelector(
//                         ".custom-check"
//                     );


//                 // تغییر ظاهر

//                 if (this.checked) {


//                     status.classList.remove(
//                         "unpaid"
//                     );


//                     status.classList.add(
//                         "paid"
//                     );


//                     statusText.textContent =
//                         "پرداخت شده";


//                     customCheck.textContent =
//                         "✓";

//                 }

//                 else {


//                     status.classList.remove(
//                         "paid"
//                     );


//                     status.classList.add(
//                         "unpaid"
//                     );


//                     statusText.textContent =
//                         "پرداخت نشده";


//                     customCheck.textContent =
//                         "×";

//                 }


//                 // ذخیره در دیتابیس

//                 savePayment(
//                     personId,
//                     paid
//                 );

//             }
//         );

//     }
// );



// // ==========================================
// // ذخیره پرداخت
// // ==========================================

// function savePayment(
//     personId,
//     paid
// ) {


//     const year =
//         document.getElementById(
//             "year"
//         ).value;


//     const month =
//         document.getElementById(
//             "month"
//         ).value;


//     const descriptionInput =
//         document.querySelector(
//             `.description-input[data-person-id="${personId}"]`
//         );


//     const description =
//         descriptionInput
//             ? descriptionInput.value
//             : "";


//     const formData =
//         new FormData();


//     formData.append(
//         "person_id",
//         personId
//     );


//     formData.append(
//         "year",
//         year
//     );


//     formData.append(
//         "month",
//         month
//     );


//     formData.append(
//         "paid",
//         paid
//     );


//     formData.append(
//         "description",
//         description
//     );


//     fetch(
//         "/free-insurance/payment/toggle",
//         {
//             method: "POST",
//             body: formData
//         }
//     )

//     .then(function (response) {

//         return response.json();

//     })

//     .then(function (data) {


//         if (!data.success) {

//             alert(
//                 "ذخیره وضعیت پرداخت انجام نشد."
//             );

//         }

//     })

//     .catch(function () {


//         alert(
//             "ارتباط با سرور برقرار نشد."
//         );

//     });

// }



// // ==========================================
// // ذخیره توضیحات
// // ==========================================

// function saveDescriptions() {


//     const checkboxes =
//         document.querySelectorAll(
//             ".payment-checkbox"
//         );


//     checkboxes.forEach(
//         function (checkbox) {


//             const personId =
//                 checkbox.dataset.personId;


//             const paid =
//                 checkbox.checked ? 1 : 0;


//             savePayment(
//                 personId,
//                 paid
//             );

//         }
//     );


//     alert(
//         "اطلاعات ذخیره شد."
//     );
// }


const personRows = document.querySelectorAll(".person-row");

// ==========================================
// جستجوی نام
// ==========================================
const searchInput = document.getElementById("searchInput");

if (searchInput) {
    searchInput.addEventListener("input", function () {
        const searchText = this.value.trim().toLowerCase();

        personRows.forEach(function (row) {
            const name = (row.dataset.name || "").toLowerCase();
            if (name.includes(searchText)) {
                row.style.display = "";
            } else {
                row.style.display = "none";
            }
        });
    });
}

// ==========================================
// فرمت خودکار تاریخ ثبت (افزودن خودکار اسلش /)
// ==========================================
const dateInputs = document.querySelectorAll(".date-input");

dateInputs.forEach(function (input) {
    input.addEventListener("input", function (e) {
        // حذف تمام کاراکترهای غیرعددی
        let v = this.value.replace(/\D/g, "");

        // محدودیت به حداکثر ۸ رقم
        if (v.length > 8) {
            v = v.substring(0, 8);
        }

        // افزودن خودکار اسلش‌ها
        if (v.length > 6) {
            this.value = v.substring(0, 4) + "/" + v.substring(4, 6) + "/" + v.substring(6);
        } else if (v.length > 4) {
            this.value = v.substring(0, 4) + "/" + v.substring(4);
        } else {
            this.value = v;
        }
    });
});

// ==========================================
// تغییر وضعیت پرداخت با چک‌باکس
// ==========================================
const paymentCheckboxes = document.querySelectorAll(".payment-checkbox");

paymentCheckboxes.forEach(function (checkbox) {
    checkbox.addEventListener("change", function () {
        const personId = this.dataset.personId;
        const paid = this.checked ? 1 : 0;
        const status = this.closest(".payment-status");
        const statusText = status.querySelector(".status-text");
        const customCheck = status.querySelector(".custom-check");

        // تغییر ظاهر
        if (this.checked) {
            status.classList.remove("unpaid");
            status.classList.add("paid");
            statusText.textContent = "پرداخت شده";
            customCheck.textContent = "✓";
        } else {
            status.classList.remove("paid");
            status.classList.add("unpaid");
            statusText.textContent = "پرداخت نشده";
            customCheck.textContent = "×";
        }

        // ذخیره در سرور
        savePayment(personId, paid);
    });
});

// ==========================================
// تابع ذخیره در دیتابیس
// ==========================================
function savePayment(personId, paid) {
    const year = document.getElementById("year").value;
    const month = document.getElementById("month").value;

    const descriptionInput = document.querySelector(
        `.description-input[data-person-id="${personId}"]`
    );
    const description = descriptionInput ? descriptionInput.value : "";

    // دریافت مقدار تاریخ ثبت
    const dateInput = document.querySelector(
        `.date-input[data-person-id="${personId}"]`
    );
    const recordDate = dateInput ? dateInput.value.trim() : "";

    const formData = new FormData();
    formData.append("person_id", personId);
    formData.append("year", year);
    formData.append("month", month);
    formData.append("paid", paid);
    formData.append("description", description);
    formData.append("record_date", recordDate); // ارسال تاریخ به سرور

    fetch("/free-insurance/payment/toggle", {
        method: "POST",
        body: formData
    })
    .then(function (response) {
        return response.json();
    })
    .then(function (data) {
        if (!data.success) {
            alert("ذخیره وضعیت انجام نشد.");
        }
    })
    .catch(function () {
        alert("ارتباط با سرور برقرار نشد.");
    });
}

// ==========================================
// دکمه سبز بالای صفحه: ذخیره اطلاعات
// ==========================================
function saveDescriptions() {
    const checkboxes = document.querySelectorAll(".payment-checkbox");

    checkboxes.forEach(function (checkbox) {
        const personId = checkbox.dataset.personId;
        const paid = checkbox.checked ? 1 : 0;
        savePayment(personId, paid);
    });

    alert("اطلاعات با موفقیت ذخیره شد.");
}
