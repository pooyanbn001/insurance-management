# import sqlite3


# DATABASE = "database/workshop_insurance.db"


# def get_workshop_db():

#     connection = sqlite3.connect(DATABASE)

#     connection.row_factory = sqlite3.Row

#     connection.execute("PRAGMA foreign_keys = ON")

#     return connection


# def create_workshop_tables():

#     connection = get_workshop_db()

#     # جدول اشخاص
#     connection.execute("""
#     CREATE TABLE IF NOT EXISTS persons (

#     id INTEGER PRIMARY KEY AUTOINCREMENT,

#     full_name TEXT NOT NULL,
    

#     mobile TEXT,

#     national_code TEXT,

#     password TEXT,

#     workshop_name TEXT,

#     workshop_code TEXT,

#     registration_date TEXT

# )

        
#     """)

#     # جدول پرداخت
#     connection.execute("""
#         CREATE TABLE IF NOT EXISTS payments (

#             id INTEGER PRIMARY KEY AUTOINCREMENT,

#             person_id INTEGER NOT NULL,

#             year INTEGER NOT NULL,

#             month TEXT NOT NULL,

#             paid INTEGER NOT NULL DEFAULT 0,
#             record_date TEXT,

#             description TEXT,

#             UNIQUE(person_id, year, month),

#             FOREIGN KEY(person_id)
#                 REFERENCES persons(id)
#                 ON DELETE CASCADE

#         )
#     """)
    



#     connection.commit()

#     connection.close()








import sqlite3

DATABASE = "database/workshop_insurance.db"


def get_workshop_db():
    connection = sqlite3.connect(DATABASE)
    connection.row_factory = sqlite3.Row
    connection.execute("PRAGMA foreign_keys = ON")
    return connection


def create_workshop_tables():
    connection = get_workshop_db()

    # جدول اشخاص
    connection.execute("""
    CREATE TABLE IF NOT EXISTS persons (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        full_name TEXT NOT NULL,
        mobile TEXT,
        national_code TEXT,
        password TEXT,
        workshop_name TEXT,
        workshop_code TEXT,
        registration_date TEXT
    )
    """)

    # جدول پرداخت
    connection.execute("""
    CREATE TABLE IF NOT EXISTS payments (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        person_id INTEGER NOT NULL,
        year INTEGER NOT NULL,
        month TEXT NOT NULL,
        paid INTEGER NOT NULL DEFAULT 0,
        record_date TEXT,
        description TEXT,
        UNIQUE(person_id, year, month),
        FOREIGN KEY(person_id)
            REFERENCES persons(id)
            ON DELETE CASCADE
    )
    """)

    connection.commit()
    connection.close()
