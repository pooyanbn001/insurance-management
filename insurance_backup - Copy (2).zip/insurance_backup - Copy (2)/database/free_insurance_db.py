
import sqlite3

DATABASE = "database/free_insurance.db"


def get_free_db():

    connection = sqlite3.connect(DATABASE)

    connection.row_factory = sqlite3.Row

    connection.execute("PRAGMA foreign_keys = ON")

    return connection


def create_free_tables():

    connection = get_free_db()

    # جدول اشخاص
    connection.execute("""
        CREATE TABLE IF NOT EXISTS persons (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            full_name TEXT NOT NULL UNIQUE,
            first_name TEXT,
            last_name TEXT,
            mobile TEXT,
            national_code TEXT,
            password TEXT
        )
    """)

    # اضافه کردن ستون‌ها به دیتابیس‌های قدیمی
    try:
        connection.execute(
            "ALTER TABLE persons ADD COLUMN first_name TEXT"
        )
    except sqlite3.OperationalError:
        pass

    try:
        connection.execute(
            "ALTER TABLE persons ADD COLUMN last_name TEXT"
        )
    except sqlite3.OperationalError:
        pass

    # جدول پرداخت
    connection.execute("""
        CREATE TABLE IF NOT EXISTS payments (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            person_id INTEGER NOT NULL,
            year INTEGER NOT NULL,
            month TEXT NOT NULL,
            paid INTEGER NOT NULL DEFAULT 0,
            description TEXT,
            record_date TEXT,

            UNIQUE(person_id, year, month),

            FOREIGN KEY(person_id)
                REFERENCES persons(id)
                ON DELETE CASCADE
        )
    """)

    try:
        connection.execute(
            "ALTER TABLE payments ADD COLUMN record_date TEXT"
        )
    except sqlite3.OperationalError:
        pass

    # اطلاعات قدیمی
    persons = connection.execute("""
        SELECT id, full_name
        FROM persons
        WHERE
            (first_name IS NULL OR first_name = '')
            AND full_name IS NOT NULL
    """).fetchall()

    for person in persons:

        parts = person["full_name"].strip().split()

        if len(parts) >= 2:

            first_name = parts[0]
            last_name = " ".join(parts[1:])

        else:

            first_name = person["full_name"]
            last_name = ""

        connection.execute("""
            UPDATE persons
            SET
                first_name = ?,
                last_name = ?
            WHERE id = ?
        """, (
            first_name,
            last_name,
            person["id"]
        ))

    connection.commit()
    connection.close()