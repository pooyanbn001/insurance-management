import sqlite3
import os

from dotenv import load_dotenv


# خواندن اطلاعات فایل .env
load_dotenv()


# مسیر دیتابیس از .env
DATABASE = os.getenv("DATABASE_PATH")


def get_db():

    connection = sqlite3.connect(DATABASE)

    connection.row_factory = sqlite3.Row

    return connection


def create_tables():

    connection = get_db()

    connection.execute("""
        CREATE TABLE IF NOT EXISTS users (

            id INTEGER PRIMARY KEY AUTOINCREMENT,

            full_name TEXT NOT NULL UNIQUE,

            password TEXT NOT NULL

        )
    """)

    connection.commit()

    connection.close()