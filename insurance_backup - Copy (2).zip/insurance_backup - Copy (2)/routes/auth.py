# from flask import Blueprint, render_template, request, redirect, url_for, session

# from database.db import get_db

# from werkzeug.security import generate_password_hash, check_password_hash


# auth = Blueprint("auth", __name__)


# @auth.route("/", methods=["GET", "POST"])
# def login():

#     # اگر کاربر قبلاً وارد شده
#     if "user_id" in session:
#         return redirect(url_for("dashboard.home"))

#     # وقتی فرم ارسال شد
#     if request.method == "POST":

#         full_name = request.form["full_name"]
#         password = request.form["password"]

#         connection = get_db()

#         # پیدا کردن کاربر
#         user = connection.execute(
#             "SELECT * FROM users WHERE full_name = ?",
#             (full_name,)
#         ).fetchone()

#         # اگر کاربر وجود نداشت
#         if user is None:

#             hashed_password = generate_password_hash(password)

#             connection.execute(
#                 """
#                 INSERT INTO users (full_name, password)
#                 VALUES (?, ?)
#                 """,
#                 (full_name, hashed_password)
#             )

#             connection.commit()

#             # دوباره کاربر را از دیتابیس می‌گیریم
#             user = connection.execute(
#                 "SELECT * FROM users WHERE full_name = ?",
#                 (full_name,)
#             ).fetchone()

#         # بررسی رمز عبور
#         if check_password_hash(user["password"], password):

#             session["user_id"] = user["id"]
#             session["full_name"] = user["full_name"]

#             connection.close()

#             return redirect(url_for("dashboard.home"))

#         connection.close()

#     return render_template("login.html")



    
    
# @auth.route("/logout")
# def logout():

#     session.clear()

#     return redirect(url_for("auth.login"))

from flask import Blueprint, render_template, request, redirect, url_for, session
from database.db import get_db

auth = Blueprint("auth", __name__)

STATIC_PASSWORD = "123456"

def normalize_digits(text: str) -> str:
    """تبدیل اعداد فارسی و عربی به انگلیسی برای جلوگیری از خطای کیبورد"""
    if not text:
        return ""
    persian_arabic_digits = {
        '۰': '0', '۱': '1', '۲': '2', '۳': '3', '۴': '4',
        '۵': '5', '۶': '6', '۷': '7', '۸': '8', '۹': '9',
        '٠': '0', '١': '1', '٢': '2', '٣': '3', '٤': '4',
        '٥': '5', '٦': '6', '٧': '7', '٨': '8', '٩': '9'
    }
    for fa_ar, en in persian_arabic_digits.items():
        text = text.replace(fa_ar, en)
    return text.strip()

@auth.route("/", methods=["GET", "POST"])
def login():
    if "user_id" in session:
        return redirect(url_for("dashboard.home"))

    error = None

    if request.method == "POST":
        full_name = request.form.get("full_name", "").strip()
        raw_password = request.form.get("password", "")
        
        # تبدیل ارقام فارسی و حذف فاصله‌ها
        password = normalize_digits(raw_password)

        if not full_name:
            error = "لطفاً نام و نام خانوادگی را وارد کنید."
        elif password != STATIC_PASSWORD:
            error = "رمز عبور اشتباه است!"
        else:
            connection = get_db()

            user = connection.execute(
                "SELECT * FROM users WHERE full_name = ?",
                (full_name,)
            ).fetchone()

            if user is None:
                connection.execute(
                    """
                    INSERT INTO users (full_name, password)
                    VALUES (?, ?)
                    """,
                    (full_name, STATIC_PASSWORD)
                )
                connection.commit()

                user = connection.execute(
                    "SELECT * FROM users WHERE full_name = ?",
                    (full_name,)
                ).fetchone()

            session["user_id"] = user["id"]
            session["full_name"] = user["full_name"]

            connection.close()
            return redirect(url_for("dashboard.home"))

    return render_template("login.html", error=error)


@auth.route("/logout")
def logout():
    session.clear()
    return redirect(url_for("auth.login"))