from flask import (
    Blueprint,
    render_template,
    redirect,
    url_for,
    session,
    request,
    jsonify
)

from database.free_insurance_db import get_free_db
from database.workshop_insurance_db import get_workshop_db


dashboard = Blueprint(
    "dashboard",
    __name__
)


# ==================================================
# صفحه اصلی
# ==================================================

@dashboard.route("/dashboard")
def home():

    if "user_id" not in session:
        return redirect(
            url_for("auth.login")
        )

    return render_template(
        "dashboard.html",
        full_name=session["full_name"]
    )


# ==================================================
# صفحه بیمه آزاد
# ==================================================

@dashboard.route("/free-insurance")
def free_insurance():

    if "user_id" not in session:
        return redirect(
            url_for("auth.login")
        )

    year = request.args.get(
        "year",
        default=1405,
        type=int
    )

    month = request.args.get(
        "month",
        default=6,
        type=int
    )

    search = request.args.get(
        "search",
        default=""
    ).strip()

    connection = get_free_db()

    persons = connection.execute(
        """
        SELECT
            persons.id,

            persons.first_name,
            persons.last_name,

            persons.full_name,
            persons.mobile,
            persons.national_code,
            persons.password,

            COALESCE(
                payments.paid,
                0
            ) AS paid,

            COALESCE(
                payments.description,
                ''
            ) AS description,

            COALESCE(
                payments.record_date,
                ''
            ) AS record_date

        FROM persons

        LEFT JOIN payments
        ON persons.id = payments.person_id
        AND payments.year = ?
        AND payments.month = ?

        WHERE
            (
                persons.first_name LIKE ?
                OR persons.last_name LIKE ?
                OR persons.full_name LIKE ?
                OR persons.national_code LIKE ?
            )

        ORDER BY persons.id ASC
        """,
        (
            year,
            month,
            f"%{search}%",
            f"%{search}%",
            f"%{search}%",
            f"%{search}%"
        )
    ).fetchall()

    connection.close()

    return render_template(
        "free_insurance.html",
        full_name=session["full_name"],
        persons=persons,
        selected_year=year,
        selected_month=month,
        search=search
    )
# ==================================================
# افزودن اشخاص بیمه آزاد
# ==================================================

@dashboard.route(
    "/free-insurance/persons",
    methods=["GET", "POST"]
)
def free_insurance_persons():

    if "user_id" not in session:
        return redirect(
            url_for("auth.login")
        )

    connection = get_free_db()

    if request.method == "POST":

        first_names = request.form.getlist(
            "first_name"
        )

        last_names = request.form.getlist(
            "last_name"
        )

        mobiles = request.form.getlist(
            "mobile"
        )

        national_codes = request.form.getlist(
            "national_code"
        )

        passwords = request.form.getlist(
            "password"
        )

        for i in range(len(first_names)):

            first_name = (
                first_names[i].strip()
                if i < len(first_names)
                else ""
            )

            last_name = (
                last_names[i].strip()
                if i < len(last_names)
                else ""
            )

            if first_name == "" and last_name == "":
                continue

            mobile = (
                mobiles[i].strip()
                if i < len(mobiles)
                else ""
            )

            national_code = (
                national_codes[i].strip()
                if i < len(national_codes)
                else ""
            )

            password = (
                passwords[i].strip()
                if i < len(passwords)
                else ""
            )

            full_name = (
                first_name + " " + last_name
            ).strip()

            existing_person = connection.execute(
                """
                SELECT id
                FROM persons
                WHERE full_name = ?
                """,
                (full_name,)
            ).fetchone()

            if existing_person:

                connection.execute(
                    """
                    UPDATE persons
                    SET
                        first_name = ?,
                        last_name = ?,
                        mobile = ?,
                        national_code = ?,
                        password = ?

                    WHERE id = ?
                    """,
                    (
                        first_name,
                        last_name,
                        mobile,
                        national_code,
                        password,
                        existing_person["id"]
                    )
                )

            else:

                connection.execute(
                    """
                    INSERT INTO persons
                    (
                        full_name,
                        first_name,
                        last_name,
                        mobile,
                        national_code,
                        password
                    )

                    VALUES (?, ?, ?, ?, ?, ?)
                    """,
                    (
                        full_name,
                        first_name,
                        last_name,
                        mobile,
                        national_code,
                        password
                    )
                )

        connection.commit()
        connection.close()

        return redirect(
            url_for(
                "dashboard.free_insurance"
            )
        )

    persons = connection.execute(
        """
        SELECT *
        FROM persons
        ORDER BY id ASC
        """
    ).fetchall()

    connection.close()

    return render_template(
        "free_insurance_persons.html",
        full_name=session["full_name"],
        persons=persons
    )
# ==================================================
# حذف شخص بیمه آزاد
# ==================================================

@dashboard.route(
    "/free-insurance/person/<int:person_id>/delete",
    methods=["POST"]
)
def delete_free_person(person_id):

    if "user_id" not in session:
        return redirect(
            url_for("auth.login")
        )

    connection = get_free_db()

    connection.execute(
        """
        DELETE FROM persons
        WHERE id = ?
        """,
        (person_id,)
    )

    connection.commit()
    connection.close()

    return redirect(
        url_for(
            "dashboard.free_insurance_persons"
        )
    )


# ==================================================
# پرداخت بیمه آزاد
# ==================================================

# @dashboard.route(
#     "/free-insurance/payment/toggle",
#     methods=["POST"]
# )
# def toggle_payment():

#     if "user_id" not in session:
#         return jsonify({
#             "success": False,
#             "message": "دسترسی غیرمجاز"
#         }), 401

#     person_id = request.form.get(
#         "person_id",
#         type=int
#     )

#     year = request.form.get(
#         "year",
#         type=int
#     )

#     month = request.form.get(
#         "month",
#         type=int
#     )

#     paid = request.form.get(
#         "paid",
#         type=int
#     )

#     description = request.form.get(
#         "description",
#         ""
#     )

#     if not person_id or not year or not month:

#         return jsonify({
#             "success": False,
#             "message": "اطلاعات ناقص است"
#         }), 400

#     connection = get_free_db()

#     payment = connection.execute(
#         """
#         SELECT id
#         FROM payments

#         WHERE person_id = ?
#         AND year = ?
#         AND month = ?
#         """,
#         (
#             person_id,
#             year,
#             month
#         )
#     ).fetchone()

#     if payment:

#         connection.execute(
#             """
#             UPDATE payments

#             SET
#                 paid = ?,
#                 description = ?

#             WHERE person_id = ?
#             AND year = ?
#             AND month = ?
#             """,
#             (
#                 paid,
#                 description,
#                 person_id,
#                 year,
#                 month
#             )
#         )

#     else:

#         connection.execute(
#             """
#             INSERT INTO payments
#             (
#                 person_id,
#                 year,
#                 month,
#                 paid,
#                 description
#             )

#             VALUES (?, ?, ?, ?, ?)
#             """,
#             (
#                 person_id,
#                 year,
#                 month,
#                 paid,
#                 description
#             )
#         )

#     connection.commit()
#     connection.close()

#     return jsonify({
#         "success": True,
#         "paid": paid
#     })


@dashboard.route(
    "/free-insurance/payment/toggle",
    methods=["POST"]
)
def toggle_payment():

    if "user_id" not in session:
        return jsonify({
            "success": False,
            "message": "دسترسی غیرمجاز"
        }), 401

    person_id = request.form.get("person_id", type=int)
    year = request.form.get("year", type=int)
    month = request.form.get("month", type=int)
    paid = request.form.get("paid", type=int)
    description = request.form.get("description", "")
    record_date = request.form.get("record_date", "")  # <-- دریافت تاریخ ثبت

    if not person_id or not year or not month:
        return jsonify({
            "success": False,
            "message": "اطلاعات ناقص است"
        }), 400

    connection = get_free_db()

    payment = connection.execute(
        """
        SELECT id
        FROM payments
        WHERE person_id = ?
        AND year = ?
        AND month = ?
        """,
        (person_id, year, month)
    ).fetchone()

    if payment:
        connection.execute(
            """
            UPDATE payments
            SET
                paid = ?,
                description = ?,
                record_date = ?
            WHERE person_id = ?
            AND year = ?
            AND month = ?
            """,
            (paid, description, record_date, person_id, year, month)
        )
    else:
        connection.execute(
            """
            INSERT INTO payments (
                person_id,
                year,
                month,
                paid,
                description,
                record_date
            )
            VALUES (?, ?, ?, ?, ?, ?)
            """,
            (person_id, year, month, paid, description, record_date)
        )

    connection.commit()
    connection.close()

    return jsonify({
        "success": True,
        "paid": paid
    })


# ==================================================
# صفحه بیمه کارگاهی
# ==================================================

# @dashboard.route("/workshop-insurance")
# def workshop_insurance():

#     if "user_id" not in session:
#         return redirect(
#             url_for("auth.login")
#         )

#     year = request.args.get(
#         "year",
#         default=1405,
#         type=int
#     )

#     month = request.args.get(
#         "month",
#         default=6,
#         type=int
#     )

#     search = request.args.get(
#         "search",
#         default=""
#     ).strip()

#     connection = get_workshop_db()

#     persons = connection.execute(
#         """
# SELECT
#     persons.id,
#     persons.full_name,
#     persons.mobile,
#     persons.national_code,
#     persons.password,
#     persons.workshop_name,
#     persons.workshop_code,
#     persons.registration_date,

#     COALESCE(
#         payments.paid,
#         0
#     ) AS paid,

#     COALESCE(
#         payments.description,
#         ''
#     ) AS description

#         FROM persons

#         LEFT JOIN payments
#         ON persons.id = payments.person_id
#         AND payments.year = ?
#         AND payments.month = ?

#         WHERE
#             persons.full_name LIKE ?
#             OR persons.national_code LIKE ?
#             OR persons.workshop_name LIKE ?
#             OR persons.workshop_code LIKE ?

#         ORDER BY persons.id ASC
#         """,
#         (
#             year,
#             month,
#             f"%{search}%",
#             f"%{search}%",
#             f"%{search}%",
#             f"%{search}%"
#         )
#     ).fetchall()

#     connection.close()

#     return render_template(
#         "workshop_insurance.html",
#         full_name=session["full_name"],
#         persons=persons,
#         selected_year=year,
#         selected_month=month,
#         search=search
#     )



@dashboard.route("/workshop-insurance")
def workshop_insurance():

    if "user_id" not in session:
        return redirect(
            url_for("auth.login")
        )

    year = request.args.get(
        "year",
        default=1405,
        type=int
    )

    month = request.args.get(
        "month",
        default=6,
        type=int
    )

    search = request.args.get(
        "search",
        default=""
    ).strip()

    connection = get_workshop_db()

    persons = connection.execute(
        """
        SELECT
            persons.id,
            persons.full_name,
            persons.mobile,
            persons.national_code,
            persons.password,
            persons.workshop_name,
            persons.workshop_code,

            COALESCE(
                payments.record_date,
                ''
            ) AS registration_date,

            COALESCE(
                payments.paid,
                0
            ) AS paid,

            COALESCE(
                payments.description,
                ''
            ) AS description

        FROM persons

        LEFT JOIN payments
            ON persons.id = payments.person_id
            AND payments.year = ?
            AND payments.month = ?

        WHERE
            persons.full_name LIKE ?
            OR persons.national_code LIKE ?
            OR persons.workshop_name LIKE ?
            OR persons.workshop_code LIKE ?

        ORDER BY persons.id ASC
        """,
        (
            year,
            month,
            f"%{search}%",
            f"%{search}%",
            f"%{search}%",
            f"%{search}%"
        )
    ).fetchall()

    connection.close()

    return render_template(
        "workshop_insurance.html",
        full_name=session["full_name"],
        persons=persons,
        selected_year=year,
        selected_month=month,
        search=search
    )

# ==================================================
# افزودن اشخاص بیمه کارگاهی
# ==================================================

# @dashboard.route(
#     "/workshop-insurance/persons",
#     methods=["GET", "POST"]
# )
# def workshop_insurance_persons():

#     if "user_id" not in session:
#         return redirect(
#             url_for("auth.login")
#         )

#     connection = get_workshop_db()

#     # ----------------------------------------------
#     # ذخیره اطلاعات
#     # ----------------------------------------------

#     if request.method == "POST":

#         names = request.form.getlist(
#             "full_name"
#         )

#         mobiles = request.form.getlist(
#             "mobile"
#         )

#         national_codes = request.form.getlist(
#             "national_code"
#         )

#         passwords = request.form.getlist(
#             "password"
#         )

#         workshop_names = request.form.getlist(
#             "workshop_name"
#         )

#         workshop_codes = request.form.getlist(
#             "workshop_code"
#         )
        
#         registration_dates = request.form.getlist(
#              "registration_date"
#         )

#         for i in range(len(names)):

#             full_name = names[i].strip()

#             if full_name == "":
#                 continue

#             mobile = (
#                 mobiles[i].strip()
#                 if i < len(mobiles)
#                 else ""
#             )

#             national_code = (
#                 national_codes[i].strip()
#                 if i < len(national_codes)
#                 else ""
#             )

#             password = (
#                 passwords[i].strip()
#                 if i < len(passwords)
#                 else ""
#             )

#             workshop_name = (
#                 workshop_names[i].strip()
#                 if i < len(workshop_names)
#                 else ""
#             )

#             workshop_code = (
#                 workshop_codes[i].strip()
#                 if i < len(workshop_codes)
#                 else ""
#             )
            
#             registration_date = (

#                 registration_dates[i].strip()
#                 if i < len(registration_dates)
#                 else ""

#                 )

#             # --------------------------------------
#             # بررسی شخص موجود
#             # --------------------------------------

#             existing_person = connection.execute(
#                 """
#                 SELECT id
#                 FROM persons

#                 WHERE full_name = ?
#                 AND workshop_code = ?
#                 """,
#                 (
#                     full_name,
#                     workshop_code
#                 )
#             ).fetchone()

#             # --------------------------------------
#             # اگر شخص وجود داشت
#             # --------------------------------------

#             if existing_person:

#                 connection.execute(
#                     """
#                     UPDATE persons

#               SET
#                   mobile = ?,
#                   national_code = ?,
#                   password = ?,
#                   workshop_name = ?,
#                   workshop_code = ?,
#                   registration_date = ?

#                     WHERE id = ?
#                     """,
# (
#     mobile,
#     national_code,
#     password,
#     workshop_name,
#     workshop_code,
#     registration_date,
#     existing_person["id"]
# )
#                 )

#             # --------------------------------------
#             # اگر شخص جدید بود
#             # --------------------------------------

#             else:

#                 connection.execute(
#                     """
# INSERT INTO persons
# (
#     full_name,
#     mobile,
#     national_code,
#     password,
#     workshop_name,
#     workshop_code,
#     registration_date
# )

# VALUES (?, ?, ?, ?, ?, ?, ?)
#                     """,
# (
#     full_name,
#     mobile,
#     national_code,
#     password,
#     workshop_name,
#     workshop_code,
#     registration_date
# )
#                 )

#         connection.commit()
#         connection.close()

#         return redirect(
#             url_for(
#                 "dashboard.workshop_insurance"
#             )
#         )

#     # ----------------------------------------------
#     # نمایش اشخاص
#     # ----------------------------------------------

#     persons = connection.execute(
#         """
#         SELECT *
#         FROM persons
#         ORDER BY id ASC
#         """
#     ).fetchall()

#     connection.close()

#     return render_template(
#         "workshop_insurance_persons.html",
#         full_name=session["full_name"],
#         persons=persons
#     )


@dashboard.route(
    "/workshop-insurance/persons",
    methods=["GET", "POST"]
)
def workshop_insurance_persons():

    if "user_id" not in session:
        return redirect(url_for("auth.login"))

    # سال و ماه انتخاب شده
    year = request.args.get(
        "year",
        request.form.get("year", 1405),
        type=int
    )

    month = request.args.get(
        "month",
        request.form.get("month", 6),
        type=int
    )

    connection = get_workshop_db()

    # ==================================================
    # ذخیره اطلاعات
    # ==================================================

    if request.method == "POST":

        # -----------------------------
        # اطلاعات فرم
        # -----------------------------

        first_names = request.form.getlist(
            "first_name"
        )

        last_names = request.form.getlist(
            "last_name"
        )

        full_names = request.form.getlist(
            "full_name"
        )

        mobiles = request.form.getlist(
            "mobile"
        )

        national_codes = request.form.getlist(
            "national_code"
        )

        passwords = request.form.getlist(
            "password"
        )

        workshop_names = request.form.getlist(
            "workshop_name"
        )

        workshop_codes = request.form.getlist(
            "workshop_code"
        )

        registration_dates = request.form.getlist(
            "registration_date"
        )

        # -----------------------------
        # تعداد ردیف‌ها
        # -----------------------------

        row_count = max(
            len(first_names),
            len(last_names),
            len(full_names)
        )

        # ==================================================
        # پردازش هر شخص
        # ==================================================

        for i in range(row_count):

            # -----------------------------
            # نام و نام خانوادگی
            # -----------------------------

            first_name = (
                first_names[i].strip()
                if i < len(first_names)
                else ""
            )

            last_name = (
                last_names[i].strip()
                if i < len(last_names)
                else ""
            )

            # اگر full_name از فرم ارسال شده باشد
            full_name = (
                full_names[i].strip()
                if i < len(full_names)
                else ""
            )

            # اگر full_name خالی بود
            # از نام و نام خانوادگی بساز
            if not full_name:

                full_name = (
                    f"{first_name} {last_name}"
                ).strip()

            # اگر اسم وارد نشده بود
            if full_name == "":
                continue

            # -----------------------------
            # سایر اطلاعات
            # -----------------------------

            mobile = (
                mobiles[i].strip()
                if i < len(mobiles)
                else ""
            )

            national_code = (
                national_codes[i].strip()
                if i < len(national_codes)
                else ""
            )

            password = (
                passwords[i].strip()
                if i < len(passwords)
                else ""
            )

            workshop_name = (
                workshop_names[i].strip()
                if i < len(workshop_names)
                else ""
            )

            workshop_code = (
                workshop_codes[i].strip()
                if i < len(workshop_codes)
                else ""
            )

            registration_date = (
                registration_dates[i].strip()
                if i < len(registration_dates)
                else ""
            )

            # ==================================================
            # بررسی شخص موجود
            # ==================================================

            existing_person = connection.execute(
                """
                SELECT id
                FROM persons
                WHERE full_name = ?
                AND workshop_code = ?
                """,
                (
                    full_name,
                    workshop_code
                )
            ).fetchone()

            # ==================================================
            # اگر شخص قبلاً وجود داشت
            # ==================================================

            if existing_person:

                person_id = existing_person["id"]

                connection.execute(
                    """
                    UPDATE persons
                    SET
                        mobile = ?,
                        national_code = ?,
                        password = ?,
                        workshop_name = ?,
                        workshop_code = ?,
                        registration_date = ?
                    WHERE id = ?
                    """,
                    (
                        mobile,
                        national_code,
                        password,
                        workshop_name,
                        workshop_code,
                        registration_date,
                        person_id
                    )
                )

            # ==================================================
            # اگر شخص جدید بود
            # ==================================================

            else:

                cursor = connection.execute(
                    """
                    INSERT INTO persons
                    (
                        full_name,
                        mobile,
                        national_code,
                        password,
                        workshop_name,
                        workshop_code,
                        registration_date
                    )
                    VALUES (?, ?, ?, ?, ?, ?, ?)
                    """,
                    (
                        full_name,
                        mobile,
                        national_code,
                        password,
                        workshop_name,
                        workshop_code,
                        registration_date
                    )
                )

                person_id = cursor.lastrowid

            # ==================================================
            # ذخیره تاریخ ثبت برای همین ماه
            # ==================================================

            payment = connection.execute(
                """
                SELECT id
                FROM payments
                WHERE person_id = ?
                AND year = ?
                AND month = ?
                """,
                (
                    person_id,
                    year,
                    month
                )
            ).fetchone()

            # -----------------------------
            # پرداخت برای این ماه وجود دارد
            # -----------------------------

            if payment:

                connection.execute(
                    """
                    UPDATE payments
                    SET record_date = ?
                    WHERE person_id = ?
                    AND year = ?
                    AND month = ?
                    """,
                    (
                        registration_date,
                        person_id,
                        year,
                        month
                    )
                )

            # -----------------------------
            # پرداخت برای این ماه وجود ندارد
            # -----------------------------

            else:

                connection.execute(
                    """
                    INSERT INTO payments
                    (
                        person_id,
                        year,
                        month,
                        paid,
                        record_date,
                        description
                    )
                    VALUES (?, ?, ?, ?, ?, ?)
                    """,
                    (
                        person_id,
                        year,
                        month,
                        0,
                        registration_date,
                        ""
                    )
                )

        connection.commit()
        connection.close()

        return redirect(
            url_for(
                "dashboard.workshop_insurance",
                year=year,
                month=month
            )
        )

    # ==================================================
    # نمایش اشخاص
    # ==================================================

    persons = connection.execute(
        """
        SELECT *
        FROM persons
        ORDER BY id ASC
        """
    ).fetchall()

    connection.close()

    return render_template(
        "workshop_insurance_persons.html",
        full_name=session["full_name"],
        persons=persons,
        selected_year=year,
        selected_month=month
    )

# ==================================================
# حذف شخص بیمه کارگاهی
# ==================================================

@dashboard.route(
    "/workshop-insurance/person/<int:person_id>/delete",
    methods=["POST"]
)
def delete_workshop_person(person_id):

    if "user_id" not in session:
        return redirect(
            url_for("auth.login")
        )

    connection = get_workshop_db()

    connection.execute(
        """
        DELETE FROM persons
        WHERE id = ?
        """,
        (person_id,)
    )

    connection.commit()
    connection.close()

    return redirect(
        url_for(
            "dashboard.workshop_insurance_persons"
        )
    )


# ==================================================
# پرداخت بیمه کارگاهی
# ==================================================

# @dashboard.route(
#     "/workshop-insurance/payment/toggle",
#     methods=["POST"]
# )
# def toggle_workshop_payment():

#     if "user_id" not in session:

#         return jsonify({
#             "success": False,
#             "message": "دسترسی غیرمجاز"
#         }), 401

#     person_id = request.form.get(
#         "person_id",
#         type=int
#     )

#     year = request.form.get(
#         "year",
#         type=int
#     )

#     month = request.form.get(
#         "month",
#         type=int
#     )

#     paid = request.form.get(
#         "paid",
#         type=int
#     )

#     description = request.form.get(
#         "description",
#         ""
#     )

#     # ----------------------------------------------
#     # بررسی اطلاعات
#     # ----------------------------------------------

#     if not person_id or not year or not month:

#         return jsonify({
#             "success": False,
#             "message": "اطلاعات ناقص است"
#         }), 400

#     connection = get_workshop_db()

#     # ----------------------------------------------
#     # بررسی پرداخت قبلی
#     # ----------------------------------------------

#     payment = connection.execute(
#         """
#         SELECT id
#         FROM payments

#         WHERE person_id = ?
#         AND year = ?
#         AND month = ?
#         """,
#         (
#             person_id,
#             year,
#             month
#         )
#     ).fetchone()

#     # ----------------------------------------------
#     # اگر پرداخت وجود دارد
#     # ----------------------------------------------

#     if payment:

#         connection.execute(
#             """
#             UPDATE payments

#             SET
#                 paid = ?,
#                 description = ?

#             WHERE person_id = ?
#             AND year = ?
#             AND month = ?
#             """,
#             (
#                 paid,
#                 description,
#                 person_id,
#                 year,
#                 month
#             )
#         )

#     # ----------------------------------------------
#     # اگر پرداخت وجود ندارد
#     # ----------------------------------------------

#     else:

#         connection.execute(
#             """
#             INSERT INTO payments
#             (
#                 person_id,
#                 year,
#                 month,
#                 paid,
#                 description
#             )

#             VALUES (?, ?, ?, ?, ?)
#             """,
#             (
#                 person_id,
#                 year,
#                 month,
#                 paid,
#                 description
#             )
#         )

#     connection.commit()
#     connection.close()

#     return jsonify({
#         "success": True,
#         "paid": paid
#     })


@dashboard.route(
    "/workshop-insurance/payment/toggle",
    methods=["POST"]
)
def toggle_workshop_payment():

    if "user_id" not in session:
        return jsonify({
            "success": False,
            "message": "دسترسی غیرمجاز"
        }), 401

    person_id = request.form.get(
        "person_id",
        type=int
    )

    year = request.form.get(
        "year",
        type=int
    )

    month = request.form.get(
        "month",
        type=int
    )

    paid = request.form.get(
        "paid",
        type=int
    )

    description = request.form.get(
        "description",
        ""
    ).strip()

    record_date = request.form.get(
        "record_date",
        ""
    ).strip()

    if not person_id or not year or not month:
        return jsonify({
            "success": False,
            "message": "اطلاعات ناقص است"
        }), 400

    connection = get_workshop_db()

    # ==================================================
    # بررسی پرداخت قبلی
    # ==================================================

    payment = connection.execute(
        """
        SELECT
            id,
            record_date
        FROM payments
        WHERE person_id = ?
        AND year = ?
        AND month = ?
        """,
        (
            person_id,
            year,
            month
        )
    ).fetchone()

    # ==================================================
    # اگر پرداخت وجود دارد
    # ==================================================

    if payment:

        # اگر تاریخ جدید ارسال نشده،
        # تاریخ قبلی پاک نشود
        if record_date == "":
            record_date = payment["record_date"] or ""

        connection.execute(
            """
            UPDATE payments
            SET
                paid = ?,
                description = ?,
                record_date = ?
            WHERE person_id = ?
            AND year = ?
            AND month = ?
            """,
            (
                paid,
                description,
                record_date,
                person_id,
                year,
                month
            )
        )

    # ==================================================
    # اگر پرداخت وجود ندارد
    # ==================================================

    else:

        connection.execute(
            """
            INSERT INTO payments
            (
                person_id,
                year,
                month,
                paid,
                record_date,
                description
            )
            VALUES (?, ?, ?, ?, ?, ?)
            """,
            (
                person_id,
                year,
                month,
                paid,
                record_date,
                description
            )
        )

    connection.commit()
    connection.close()

    return jsonify({
        "success": True,
        "paid": paid
    })

# ==================================================
# تاریخچه
# ==================================================

# @dashboard.route("/history")
# def history():

#     if "user_id" not in session:
#         return redirect(
#             url_for("auth.login")
#         )

#     return "صفحه تاریخچه"
# from database.free_insurance_db import get_free_db
# from database.workshop_insurance_db import get_workshop_db

# # ==================================================
# # تاریخچه
# # ==================================================
# @dashboard.route("/history", methods=["GET"])
# def history():
#     if "user_id" not in session:
#         return redirect(url_for("auth.login"))

#     # لیست ماه‌ها همراه با عدد معادل آن‌ها در دیتابیس
#     months_list = [
#         {"id": 1, "name": "فروردین"},
#         {"id": 2, "name": "اردیبهشت"},
#         {"id": 3, "name": "خرداد"},
#         {"id": 4, "name": "تیر"},
#         {"id": 5, "name": "مرداد"},
#         {"id": 6, "name": "شهریور"},
#         {"id": 7, "name": "مهر"},
#         {"id": 8, "name": "آبان"},
#         {"id": 9, "name": "آذر"},
#         {"id": 10, "name": "دی"},
#         {"id": 11, "name": "بهمن"},
#         {"id": 12, "name": "اسفند"}
#     ]
#     years = ["1403", "1404", "1405", "1406", "1407"]

#     # دریافت پارامترها (پیش‌فرض سال 1405 و ماه 6 معادل شهریور)
#     free_q = request.args.get("free_q", "").strip()
#     free_year = request.args.get("free_year", "1405").strip()
#     free_month = request.args.get("free_month", "6").strip()

#     ws_q = request.args.get("ws_q", "").strip()
#     ws_year = request.args.get("ws_year", "1405").strip()
#     ws_month = request.args.get("ws_month", "6").strip()

#     # --- استعلام بیمه آزاد ---
    
#     free_conn = get_free_db()
#     free_params = [free_year, free_month]
#     free_sql = """
#         SELECT p.id, p.full_name, p.mobile, p.national_code, p.password,
#                COALESCE(pay.paid, 0) as paid, 
#                pay.description,
#                pay.record_date
#         FROM persons p
#         LEFT JOIN payments pay 
#                ON p.id = pay.person_id 
#               AND pay.year = ? 
#               AND (pay.month = ? OR pay.month = CAST(? AS TEXT))
#     """
#     free_params.append(free_month)

#     if free_q:
#         free_sql += " WHERE (p.full_name LIKE ? OR p.national_code LIKE ?)"
#         free_params.extend([f"%{free_q}%", f"%{free_q}%"])

#     free_sql += " ORDER BY p.id ASC"
#     free_records = free_conn.execute(free_sql, free_params).fetchall()
#     free_conn.close()


#     # --- استعلام بیمه کارگاهی ---
#     ws_conn = get_workshop_db()
#     ws_params = [ws_year, ws_month]
#     ws_sql = """
#         SELECT p.id, p.full_name, p.mobile, p.national_code, p.password,
#                p.workshop_name, p.workshop_code,
#                COALESCE(pay.paid, 0) as paid, 
#                pay.description
#         FROM persons p
#         LEFT JOIN payments pay 
#                ON p.id = pay.person_id 
#               AND pay.year = ? 
#               AND (pay.month = ? OR pay.month = CAST(? AS TEXT))
#     """
#     ws_params.append(ws_month)

#     if ws_q:
#         ws_sql += " WHERE (p.full_name LIKE ? OR p.workshop_name LIKE ? OR p.workshop_code LIKE ?)"
#         ws_params.extend([f"%{ws_q}%", f"%{ws_q}%", f"%{ws_q}%"])

#     ws_sql += " ORDER BY p.id ASC"
#     ws_records = ws_conn.execute(ws_sql, ws_params).fetchall()
#     ws_conn.close()

#     return render_template(
#         "history.html",
#         free_records=free_records,
#         ws_records=ws_records,
#         years=years,
#         months=months_list,
#         free_q=free_q,
#         free_year=free_year,
#         free_month=free_month,
#         ws_q=ws_q,
#         ws_year=ws_year,
#         ws_month=ws_month
#     )

from database.free_insurance_db import get_free_db
from database.workshop_insurance_db import get_workshop_db


# ==================================================
# تاریخچه
# ==================================================

@dashboard.route("/history", methods=["GET"])
def history():

    if "user_id" not in session:
        return redirect(url_for("auth.login"))

    # ==================================================
    # لیست ماه‌ها
    # ==================================================

    months_list = [
        {"id": 1, "name": "فروردین"},
        {"id": 2, "name": "اردیبهشت"},
        {"id": 3, "name": "خرداد"},
        {"id": 4, "name": "تیر"},
        {"id": 5, "name": "مرداد"},
        {"id": 6, "name": "شهریور"},
        {"id": 7, "name": "مهر"},
        {"id": 8, "name": "آبان"},
        {"id": 9, "name": "آذر"},
        {"id": 10, "name": "دی"},
        {"id": 11, "name": "بهمن"},
        {"id": 12, "name": "اسفند"}
    ]

    years = [
        "1403",
        "1404",
        "1405",
        "1406",
        "1407"
    ]

    # ==================================================
    # دریافت پارامترها
    # ==================================================

    free_q = request.args.get(
        "free_q",
        ""
    ).strip()

    free_year = request.args.get(
        "free_year",
        "1405"
    ).strip()

    free_month = request.args.get(
        "free_month",
        "6"
    ).strip()

    ws_q = request.args.get(
        "ws_q",
        ""
    ).strip()

    ws_year = request.args.get(
        "ws_year",
        "1405"
    ).strip()

    ws_month = request.args.get(
        "ws_month",
        "6"
    ).strip()

    # ==================================================
    # استعلام بیمه آزاد
    # ==================================================

    free_conn = get_free_db()

    free_params = [
        free_year,
        free_month
    ]

    free_sql = """
        SELECT
            p.id,
            p.full_name,
            p.mobile,
            p.national_code,
            p.password,

            COALESCE(
                pay.paid,
                0
            ) AS paid,

            COALESCE(
                pay.description,
                ''
            ) AS description,

            COALESCE(
                pay.record_date,
                ''
            ) AS record_date

        FROM persons p

        LEFT JOIN payments pay
            ON p.id = pay.person_id
            AND pay.year = ?
            AND (
                pay.month = ?
                OR pay.month = CAST(? AS TEXT)
            )
    """

    free_params.append(
        free_month
    )

    if free_q:

        free_sql += """
            WHERE
                (
                    p.full_name LIKE ?
                    OR p.national_code LIKE ?
                )
        """

        free_params.extend([
            f"%{free_q}%",
            f"%{free_q}%"
        ])

    free_sql += """
        ORDER BY p.id ASC
    """

    free_records = free_conn.execute(
        free_sql,
        free_params
    ).fetchall()

    free_conn.close()

    # ==================================================
    # استعلام بیمه کارگاهی
    # ==================================================

    ws_conn = get_workshop_db()

    ws_params = [
        ws_year,
        ws_month
    ]

    ws_sql = """
        SELECT
            p.id,
            p.full_name,
            p.mobile,
            p.national_code,
            p.password,

            p.workshop_name,
            p.workshop_code,

            COALESCE(
                pay.paid,
                0
            ) AS paid,

            COALESCE(
                pay.description,
                ''
            ) AS description,

            COALESCE(
                pay.record_date,
                ''
            ) AS record_date

        FROM persons p

        LEFT JOIN payments pay
            ON p.id = pay.person_id
            AND pay.year = ?
            AND (
                pay.month = ?
                OR pay.month = CAST(? AS TEXT)
            )
    """

    ws_params.append(
        ws_month
    )

    if ws_q:

        ws_sql += """
            WHERE
                (
                    p.full_name LIKE ?
                    OR p.workshop_name LIKE ?
                    OR p.workshop_code LIKE ?
                )
        """

        ws_params.extend([
            f"%{ws_q}%",
            f"%{ws_q}%",
            f"%{ws_q}%"
        ])

    ws_sql += """
        ORDER BY p.id ASC
    """

    ws_records = ws_conn.execute(
        ws_sql,
        ws_params
    ).fetchall()

    ws_conn.close()

    # ==================================================
    # نمایش صفحه تاریخچه
    # ==================================================

    return render_template(
        "history.html",

        free_records=free_records,
        ws_records=ws_records,

        years=years,
        months=months_list,

        free_q=free_q,
        free_year=free_year,
        free_month=free_month,

        ws_q=ws_q,
        ws_year=ws_year,
        ws_month=ws_month
    )
    
#پی دی اف

@dashboard.route("/history/pdf", methods=["GET"])
def history_pdf():

    if "user_id" not in session:
        return redirect(url_for("auth.login"))

    # نوع بیمه
    insurance_type = request.args.get(
        "type",
        "workshop"
    )

    # سال و ماه
    selected_year = request.args.get(
        "year",
        "1405"
    ).strip()

    selected_month = request.args.get(
        "month",
        "6"
    ).strip()

    search_query = request.args.get(
        "search",
        ""
    ).strip()

    records = []

    # =========================
    # بیمه کارگاهی
    # =========================

    if insurance_type == "workshop":

        conn = get_workshop_db()

        sql = """
            SELECT
                p.id,
                p.full_name,
                p.mobile,
                p.national_code,
                p.password,
                p.workshop_name,
                p.workshop_code,

                COALESCE(
                    pay.paid,
                    0
                ) AS paid,

                COALESCE(
                    pay.description,
                    ''
                ) AS description,

                COALESCE(
                    pay.record_date,
                    ''
                ) AS record_date

            FROM persons p

            LEFT JOIN payments pay
                ON p.id = pay.person_id
                AND pay.year = ?
                AND (
                    pay.month = ?
                    OR pay.month = CAST(? AS TEXT)
                )
        """

        params = [
            selected_year,
            selected_month,
            selected_month
        ]

        if search_query:

            sql += """
                WHERE
                    p.full_name LIKE ?
                    OR p.mobile LIKE ?
                    OR p.national_code LIKE ?
                    OR p.workshop_name LIKE ?
                    OR p.workshop_code LIKE ?
            """

            search_text = f"%{search_query}%"

            params.extend([
                search_text,
                search_text,
                search_text,
                search_text,
                search_text
            ])

        sql += """
            ORDER BY p.id ASC
        """

        records = conn.execute(
            sql,
            params
        ).fetchall()

        conn.close()

    # =========================
    # بیمه آزاد
    # =========================

    else:

        conn = get_free_db()

        sql = """
            SELECT
                p.id,
                p.full_name,
                p.mobile,
                p.national_code,
                p.password,

                COALESCE(
                    pay.paid,
                    0
                ) AS paid,

                COALESCE(
                    pay.description,
                    ''
                ) AS description,

                COALESCE(
                    pay.record_date,
                    ''
                ) AS record_date

            FROM persons p

            LEFT JOIN payments pay
                ON p.id = pay.person_id
                AND pay.year = ?
                AND (
                    pay.month = ?
                    OR pay.month = CAST(? AS TEXT)
                )
        """

        params = [
            selected_year,
            selected_month,
            selected_month
        ]

        if search_query:

            sql += """
                WHERE
                    p.full_name LIKE ?
                    OR p.mobile LIKE ?
                    OR p.national_code LIKE ?
            """

            search_text = f"%{search_query}%"

            params.extend([
                search_text,
                search_text,
                search_text
            ])

        sql += """
            ORDER BY p.id ASC
        """

        records = conn.execute(
            sql,
            params
        ).fetchall()

        conn.close()

    # نام ماه
    months = {
        "1": "فروردین",
        "2": "اردیبهشت",
        "3": "خرداد",
        "4": "تیر",
        "5": "مرداد",
        "6": "شهریور",
        "7": "مهر",
        "8": "آبان",
        "9": "آذر",
        "10": "دی",
        "11": "بهمن",
        "12": "اسفند"
    }

    month_name = months.get(
        selected_month,
        selected_month
    )

    return render_template(
        "history_pdf.html",
        records=records,
        insurance_type=insurance_type,
        selected_year=selected_year,
        selected_month=selected_month,
        month_name=month_name,
        search_query=search_query
    )


# # --- صفحه اصلی گزارشات (شامل دو باکس آزاد و کارگاهی) ---
# @dashboard.route("/reports")
# def reports():
#     if "user_id" not in session:
#         return redirect(url_for("auth.login"))
#     return render_template("reports.html")

# # --- صفحه گزارشات بیمه آزاد (مطابق تصویر ارسالی) ---
# @dashboard.route("/reports/free")
# def reports_free():
#     if "user_id" not in session:
#         return redirect(url_for("auth.login"))
    
#     conn = get_free_db()
#     cursor = conn.cursor()
    
#     # دریافت لیست اشخاص به همراه وضعیت پرداخت و آخرین تاریخ
#     query = """
#         SELECT 
#             p.id,
#             p.first_name,
#             p.last_name,
#             p.mobile,
#             p.national_code,
#             p.password,
#             COALESCE(pay.paid, 0) as paid,
#             COALESCE(pay.record_date, '') as record_date,
#             COALESCE(pay.description, '') as description
#         FROM persons p
#         LEFT JOIN payments pay ON p.id = pay.person_id
#         ORDER BY p.id DESC
#     """
#     cursor.execute(query)
#     records = cursor.fetchall()
#     conn.close()
    
#     return render_template("reports_free.html", records=records)


# ۱. صفحه اصلی گزارشات (انتخاب آزاد یا کارگاهی)
@dashboard.route("/reports")
def reports():
    if "user_id" not in session:
        return redirect(url_for("auth.login"))
    return render_template("reports.html")


# ۲. صفحه گزارش بیمه آزاد
@dashboard.route("/reports/free", methods=["GET"])
def reports_free():
    if "user_id" not in session:
        return redirect(url_for("auth.login"))
    
    selected_year = request.args.get("year", "1405")
    selected_month = request.args.get("month", "6")
    search_query = request.args.get("search", "").strip()

    conn = get_free_db()
    cursor = conn.cursor()
  
    sql = """
        SELECT 
            p.id,
            p.first_name,
            p.last_name,
            p.mobile,
            p.national_code,
            p.password,
            COALESCE(pay.paid, 0) as paid,
            COALESCE(pay.record_date, '') as record_date,
            COALESCE(pay.description, '') as description
        FROM persons p
        LEFT JOIN payments pay ON p.id = pay.person_id 
            AND (pay.year = ? OR pay.year = CAST(? AS TEXT))
            AND (pay.month = ? OR pay.month = CAST(? AS TEXT))
        WHERE 1=1
    """
    params = [selected_year, selected_year, selected_month, selected_month]

    if search_query:
        sql += " AND (p.last_name LIKE ? OR p.first_name LIKE ? OR p.national_code LIKE ?)"
        term = f"%{search_query}%"
        params.extend([term, term, term])

    sql += " ORDER BY p.id ASC"

    cursor.execute(sql, params)
    records = cursor.fetchall()
    conn.close()

    months = [
        (1, "فروردین"), (2, "اردیبهشت"), (3, "خرداد"),
        (4, "تیر"), (5, "مرداد"), (6, "شهریور"),
        (7, "مهر"), (8, "آبان"), (9, "آذر"),
        (10, "دی"), (11, "بهمن"), (12, "اسفند")
    ]
    years = [ 1405, 1406, 1407]

    return render_template(
        "reports_free.html",
        records=records,
        selected_year=str(selected_year),
        selected_month=str(selected_month),
        search_query=search_query,
        months=months,
        years=years
    )










from database.workshop_insurance_db import get_workshop_db


@dashboard.route("/reports/workshop", methods=["GET"])
def reports_workshop():

    if "user_id" not in session:
        return redirect(url_for("auth.login"))

    selected_year = request.args.get("year", "1405")
    selected_month = request.args.get("month", "6")
    search_query = request.args.get("search", "").strip()

    conn = get_workshop_db()
    cursor = conn.cursor()

    sql = """
        SELECT

            p.id,
            p.full_name,
            p.mobile,
            p.national_code,
            p.password,
            p.workshop_name,
            p.workshop_code,
            COALESCE(
    pay.record_date,
    ''
) AS registration_date,

            COALESCE(pay.paid, 0) AS paid,
            COALESCE(pay.description, '') AS description

        FROM persons p

        LEFT JOIN payments pay
            ON p.id = pay.person_id
            AND pay.year = ?
            AND pay.month = ?

        WHERE 1=1
    """

    params = [
        int(selected_year),
        str(selected_month)
    ]

    # جستجو
    if search_query:

        sql += """
            AND (
                p.full_name LIKE ?
                OR p.national_code LIKE ?
                OR p.mobile LIKE ?
                OR p.workshop_name LIKE ?
                OR p.workshop_code LIKE ?
            )
        """

        term = f"%{search_query}%"

        params.extend([
            term,
            term,
            term,
            term,
            term
        ])

    sql += """
        ORDER BY p.id ASC
    """

    cursor.execute(sql, params)

    records = cursor.fetchall()

    conn.close()

    months = [
        (1, "فروردین"),
        (2, "اردیبهشت"),
        (3, "خرداد"),
        (4, "تیر"),
        (5, "مرداد"),
        (6, "شهریور"),
        (7, "مهر"),
        (8, "آبان"),
        (9, "آذر"),
        (10, "دی"),
        (11, "بهمن"),
        (12, "اسفند")
    ]

    years = [
        1405,
        1406,
        1407
    ]

    return render_template(
        "reports_workshop.html",
        records=records,
        selected_year=str(selected_year),
        selected_month=str(selected_month),
        search_query=search_query,
        months=months,
        years=years
    )



