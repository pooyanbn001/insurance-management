from database.workshop_insurance_db import get_workshop_db

conn = get_workshop_db()

conn.execute("""
    ALTER TABLE payments
    ADD COLUMN record_date TEXT
""")

conn.commit()
conn.close()

print("record_date اضافه شد")